import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-play-list-header',
  templateUrl: './play-list-header.component.html',
  styleUrls: ['./play-list-header.component.css']
})
export class PlayListHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
