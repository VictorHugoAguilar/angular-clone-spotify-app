export interface ArtistModel {
    name: string;
    nickname: string;
    nationality: string
}
