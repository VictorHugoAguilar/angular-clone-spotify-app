export const environment = {
  production: true,
  api: 'https://api-spotify-leifer.herokuapp.com/api/1.0'
};
